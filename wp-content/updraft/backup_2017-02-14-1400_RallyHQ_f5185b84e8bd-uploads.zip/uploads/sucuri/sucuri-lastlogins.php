<?php exit(0); ?>
{"user_id":2,"user_login":"developer","user_remoteaddr":"127.0.0.1","user_hostname":"localhost","user_lastlogin":"2017-02-11 22:57:46"}
