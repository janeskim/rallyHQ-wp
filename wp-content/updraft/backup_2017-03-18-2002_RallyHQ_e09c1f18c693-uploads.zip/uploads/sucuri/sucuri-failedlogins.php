<?php exit(0); ?>
{"user_login":"violetforest","user_password":"","attempt_time":1489867077,"remote_addr":"127.0.0.1","user_agent":"Mozilla\/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/56.0.2924.87 Safari\/537.36"}
